---
name: risu-module-workspace
description: Workspace-only skill template for editing an unpacked RisuAI module workspace and repacking it through the CLI.
---

# Workspace Risu Module Skill

This file is a **workspace-only skill template** for an unpacked RisuAI module workspace.
Use it for module-specific editing rules inside this workspace.
It is not a skill for changing the pack/unpack tool repository itself.

## Main editable areas

- `src/lorebook/`
- `src/regex/`
- `src/trigger.lua`
- `src/trigger.json`
- `assets/`

## Files that need extra care

- `src/trigger.unsupported.txt` is a notice file, not a normal editable trigger source.
- `src/*.meta.json` stores source ordering and mapping metadata.
- Edit only the trigger source files that actually exist in the workspace.
- Touch `assets/` only when asset changes are actually needed.

## Note

- This skill is **for unpacked workspaces only**.
- Do not confuse it with the `AGENTS.md` or `.agents/skills` files used by the `risu-workspace-tools` repository itself.
