---
name: risu-bot-workspace
description: Workspace-only skill template for editing an unpacked RisuAI bot workspace and repacking it through the CLI.
---

# Workspace Risu Bot Skill

This file is a **workspace-only skill template** for an unpacked RisuAI bot workspace.
Use it for bot-specific editing rules inside this workspace.
It is not a skill for changing the pack/unpack tool repository itself.

## Main editable areas

- `src/card/`
- `src/module/` when an embedded `module.risum` exists
- `assets/`

## Files that need extra care

- `src/module/` exists only when the bot contains an embedded `module.risum`.
- Touch `assets/` only when asset changes are actually needed.

## Note

- This skill is **for unpacked workspaces only**.
- Do not confuse it with the `AGENTS.md` or `.agents/skills` files used by the `risu-workspace-tools` repository itself.
